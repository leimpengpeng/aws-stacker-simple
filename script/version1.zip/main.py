import json

def lambda_handler(event, context):
    print('\n\n\n\n\n\n\n\n\n\n\n\n## ENVIRONMENT VARIABLES')
    print(f'\n\n\n\n\n\n\n\n\nWelcome... This is a test Lambda Function')
    return 'Welcome... This is a test Lambda Function'

